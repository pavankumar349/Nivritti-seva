/* fonts */
export const FontFamily = {
  dMSansRegular: "DMSans-Regular",
  dMSansMedium: "DMSans-Medium",
  dMSansBold: "DMSans-Bold",
  poppinsRegular: "Poppins-Regular",
  poppinsMedium: "Poppins-Medium",
};
/* font sizes */
export const FontSize = {
  size_base: 16,
  size_smi: 13,
  size_3xl: 22,
  size_16xl: 35,
  size_mini: 15,
  size_sm: 14,
  size_21xl: 40,
  size_xl: 20,
  size_xs: 12,
};
/* Colors */
export const Color = {
  colorWhite: "#fff",
  colorRoyalblue_100: "#5064c0",
  colorRoyalblue_200: "#4f64c0",
  colorRoyalblue_300: "#5063bf",
  colorRoyalblue_400: "rgba(81, 100, 191, 0.65)",
  colorGray_100: "#878787",
  colorGray_200: "#1e1e1e",
  colorDeepskyblue: "#38b6ff",
  colorWhitesmoke: "#eee",
  colorDarkgray: "#b1b1b1",
  colorSilver: "#c4c4c4",
  colorMediumslateblue: "#0166ff",
  colorBlack: "#000",
  colorMidnightblue: "#001a4d",
};
/* border radiuses */
export const Border = {
  br_29xl: 48,
  br_xl: 20,
  br_31xl: 50,
  br_3xs: 10,
};
