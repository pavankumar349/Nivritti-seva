const Stack = createNativeStackNavigator();
import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { useFonts } from "expo-font";
import SplashScreen from "./screens/SplashScreen";
import SplashScreen1 from "./screens/SplashScreen1";
import SplashScreen2 from "./screens/SplashScreen2";
import SplashScreen3 from "./screens/SplashScreen3";
import SplashScreen4 from "./screens/SplashScreen4";
import SplashScreen5 from "./screens/SplashScreen5";
import SplashScreen6 from "./screens/SplashScreen6";
import SplashScreen7 from "./screens/SplashScreen7";
import SplashScreen8 from "./screens/SplashScreen8";
import SplashScreen9 from "./screens/SplashScreen9";
import SplashScreen10 from "./screens/SplashScreen10";
import SplashScreen11 from "./screens/SplashScreen11";
import SplashScreen12 from "./screens/SplashScreen12";
import SplashScreen13 from "./screens/SplashScreen13";
import SplashScreen14 from "./screens/SplashScreen14";
import SplashScreen15 from "./screens/SplashScreen15";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text, Pressable, TouchableOpacity } from "react-native";

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(true);

  const [fontsLoaded, error] = useFonts({
    "DMSans-Regular": require("./assets/fonts/DMSans-Regular.ttf"),
    "DMSans-Medium": require("./assets/fonts/DMSans-Medium.ttf"),
    "DMSans-Bold": require("./assets/fonts/DMSans-Bold.ttf"),
    "Poppins-Regular": require("./assets/fonts/Poppins-Regular.ttf"),
    "Poppins-Medium": require("./assets/fonts/Poppins-Medium.ttf"),
  });

  if (!fontsLoaded && !error) {
    return null;
  }

  return (
    <>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen
              name="SplashScreen"
              component={SplashScreen}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SplashScreen1"
              component={SplashScreen1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SplashScreen2"
              component={SplashScreen2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SplashScreen3"
              component={SplashScreen3}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SplashScreen4"
              component={SplashScreen4}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SplashScreen5"
              component={SplashScreen5}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SplashScreen6"
              component={SplashScreen6}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SplashScreen7"
              component={SplashScreen7}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SplashScreen8"
              component={SplashScreen8}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SplashScreen9"
              component={SplashScreen9}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SplashScreen10"
              component={SplashScreen10}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SplashScreen11"
              component={SplashScreen11}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SplashScreen12"
              component={SplashScreen12}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SplashScreen13"
              component={SplashScreen13}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SplashScreen14"
              component={SplashScreen14}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SplashScreen15"
              component={SplashScreen15}
              options={{ headerShown: false }}
            />
          </Stack.Navigator>
        ) : null}
      </NavigationContainer>
    </>
  );
};
export default App;
