import React, { useMemo } from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const GroupComponent = ({ propBackgroundColor, onGroupPressablePress }) => {
  const rectangleViewStyle = useMemo(() => {
    return {
      ...getStyleValue("backgroundColor", propBackgroundColor),
    };
  }, [propBackgroundColor]);

  return (
    <Pressable style={styles.rectangleParent} onPress={onGroupPressablePress}>
      <View style={[styles.groupChild, styles.groupLayout]} />
      <View
        style={[styles.groupItem, styles.groupLayout, rectangleViewStyle]}
      />
      <Text style={styles.confirm}>Confirm</Text>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  groupLayout: {
    height: 62,
    borderRadius: Border.br_xl,
    left: 0,
    width: 209,
    position: "absolute",
  },
  groupChild: {
    top: 0,
    backgroundColor: Color.colorDeepskyblue,
  },
  groupItem: {
    top: 14,
    backgroundColor: Color.colorRoyalblue_200,
  },
  confirm: {
    top: 17,
    left: 56,
    fontSize: FontSize.size_3xl,
    fontWeight: "700",
    fontFamily: FontFamily.dMSansBold,
    color: Color.colorWhite,
    textAlign: "left",
    width: 99,
    height: 27,
    position: "absolute",
  },
  rectangleParent: {
    top: 388,
    left: 92,
    height: 75,
    width: 209,
    position: "absolute",
  },
});

export default GroupComponent;
