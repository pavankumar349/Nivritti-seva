import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import GroupComponent from "../components/GroupComponent";
import { Border, FontFamily, Color, FontSize } from "../GlobalStyles";

const SplashScreen8 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.splashScreen9}>
      <View style={styles.splashScreen9Child} />
      <Text style={styles.phoneNumber}>Phone Number</Text>
      <Text style={styles.pleaseAddYour}>{`Please add your
mobile phone number`}</Text>
      <Pressable
        style={styles.rectangleParent}
        onPress={() => navigation.navigate("SplashScreen7")}
      >
        <View style={[styles.groupChild, styles.groupLayout]} />
        <View style={[styles.groupItem, styles.groupLayout]} />
      </Pressable>
      <Image
        style={styles.arrowToTopIcon}
        contentFit="cover"
        source={require("../assets/arrow-to-top.png")}
      />
      <Text style={[styles.phoneNumber1, styles.textTypo]}>* Phone Number</Text>
      <Text style={[styles.text, styles.textTypo]}>+91 9965874215</Text>
      <View style={styles.splashScreen9Item} />
      <GroupComponent
        onGroupPressablePress={() => navigation.navigate("SplashScreen9")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  groupLayout: {
    height: 36,
    borderRadius: Border.br_xl,
    width: 66,
    left: 0,
    position: "absolute",
  },
  textTypo: {
    fontFamily: FontFamily.dMSansRegular,
    left: 35,
    textAlign: "left",
    position: "absolute",
  },
  splashScreen9Child: {
    width: 393,
    height: 851,
    left: 0,
    top: 0,
    position: "absolute",
    backgroundColor: Color.colorWhite,
  },
  phoneNumber: {
    top: 37,
    left: 127,
    fontSize: FontSize.size_xl,
    lineHeight: 42,
    fontWeight: "700",
    fontFamily: FontFamily.dMSansBold,
    color: Color.colorGray_200,
    width: 151,
    height: 44,
    textAlign: "left",
    position: "absolute",
  },
  pleaseAddYour: {
    top: 85,
    left: 70,
    fontSize: FontSize.size_base,
    lineHeight: 26,
    fontWeight: "500",
    fontFamily: FontFamily.dMSansMedium,
    color: Color.colorSilver,
    textAlign: "center",
    width: 256,
    height: 55,
    position: "absolute",
  },
  groupChild: {
    backgroundColor: Color.colorDeepskyblue,
    top: 0,
    borderRadius: Border.br_xl,
  },
  groupItem: {
    top: 8,
    backgroundColor: Color.colorRoyalblue_200,
  },
  rectangleParent: {
    top: 41,
    left: 37,
    width: 66,
    height: 44,
    position: "absolute",
  },
  arrowToTopIcon: {
    top: 46,
    left: 57,
    width: 25,
    height: 25,
    position: "absolute",
  },
  phoneNumber1: {
    top: 253,
    fontSize: FontSize.size_xs,
    color: Color.colorGray_100,
    width: 113,
  },
  text: {
    top: 287,
    fontSize: FontSize.size_sm,
    color: Color.colorDarkgray,
    width: 147,
    height: 18,
  },
  splashScreen9Item: {
    top: 323,
    borderStyle: "solid",
    borderColor: Color.colorGray_100,
    borderTopWidth: 1,
    width: 324,
    height: 1,
    left: 35,
    position: "absolute",
  },
  splashScreen9: {
    borderRadius: Border.br_29xl,
    flex: 1,
    width: "100%",
    height: 852,
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
  },
});

export default SplashScreen8;
