import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const SplashScreen14 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.splashScreen15}>
      <View style={styles.splashScreen15Child} />
      <Text style={styles.setPinCode}>Set Pin Code</Text>
      <Text style={[styles.text, styles.textTypo2]}>1</Text>
      <Text style={styles.text1}>4</Text>
      <Text style={styles.pleaseSetYourContainer}>
        Please set your ownPin Code
      </Text>
      <Pressable
        style={styles.rectangleParent}
        onPress={() => navigation.navigate("SplashScreen10")}
      >
        <View style={[styles.groupChild, styles.groupLayout]} />
        <View style={[styles.groupItem, styles.groupLayout]} />
      </Pressable>
      <Image
        style={styles.arrowToTopIcon}
        contentFit="cover"
        source={require("../assets/arrow-to-top.png")}
      />
      <Text style={[styles.setPinCode1, styles.setFlexBox]}>
        Set Pin Code (5-digit)
      </Text>
      <Pressable
        style={styles.rectangleGroup}
        onPress={() => navigation.navigate("SplashScreen11")}
      >
        <View style={[styles.groupInner, styles.groupInnerLayout]} />
        <View style={[styles.rectangleView, styles.groupInnerLayout]} />
        <Text style={[styles.set, styles.setFlexBox]}>Set</Text>
      </Pressable>
      <Image
        style={styles.splashScreen15Item}
        contentFit="cover"
        source={require("../assets/group-5.png")}
      />
      <Image
        style={styles.splashScreen15Inner}
        contentFit="cover"
        source={require("../assets/group-6.png")}
      />
      <Text style={[styles.text2, styles.textTypo2]}>2</Text>
      <Text style={[styles.text3, styles.textTypo1]}>5</Text>
      <Text style={[styles.text4, styles.textTypo1]}>8</Text>
      <Text style={[styles.text5, styles.textTypo1]}>0</Text>
      <Text style={[styles.text6, styles.textTypo]}>3</Text>
      <Text style={[styles.text7, styles.textTypo]}>6</Text>
      <Text style={[styles.text8, styles.textTypo]}>9</Text>
      <Text style={styles.text9}>7</Text>
      <Image
        style={[styles.androidFaceIcon, styles.androidIconLayout]}
        contentFit="cover"
        source={require("../assets/android-face.png")}
      />
      <Image
        style={[styles.androidFingerprintIcon, styles.androidIconLayout]}
        contentFit="cover"
        source={require("../assets/android-fingerprint.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  textTypo2: {
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    top: 337,
    height: 44,
    textAlign: "left",
    lineHeight: 42,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  groupLayout: {
    height: 36,
    backgroundColor: Color.colorDeepskyblue,
    borderRadius: Border.br_xl,
    width: 66,
    left: 0,
    position: "absolute",
  },
  setFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  groupInnerLayout: {
    height: 62,
    width: 123,
    backgroundColor: Color.colorDeepskyblue,
    borderRadius: Border.br_xl,
    left: 0,
    position: "absolute",
  },
  textTypo1: {
    left: 189,
    width: 14,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    height: 44,
    textAlign: "left",
    lineHeight: 42,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  textTypo: {
    left: 293,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    height: 44,
    textAlign: "left",
    lineHeight: 42,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  androidIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  splashScreen15Child: {
    width: 393,
    left: 0,
    top: 0,
    position: "absolute",
    height: 852,
    backgroundColor: Color.colorWhite,
  },
  setPinCode: {
    top: 37,
    left: 139,
    width: 179,
    height: 44,
    lineHeight: 42,
    fontSize: FontSize.size_xl,
    textAlign: "left",
    color: Color.colorGray_200,
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
    position: "absolute",
  },
  text: {
    left: 90,
    width: 8,
    color: Color.colorGray_200,
  },
  text1: {
    width: 14,
    left: 87,
    top: 427,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    height: 44,
    textAlign: "left",
    color: Color.colorGray_200,
    lineHeight: 42,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  pleaseSetYourContainer: {
    top: 85,
    left: 110,
    fontSize: FontSize.size_base,
    lineHeight: 26,
    fontFamily: FontFamily.dMSansMedium,
    color: Color.colorSilver,
    textAlign: "center",
    width: 175,
    height: 55,
    fontWeight: "500",
    position: "absolute",
  },
  groupChild: {
    top: 0,
  },
  groupItem: {
    top: 8,
  },
  rectangleParent: {
    top: 41,
    left: 37,
    width: 66,
    height: 44,
    position: "absolute",
  },
  arrowToTopIcon: {
    top: 46,
    left: 57,
    width: 25,
    height: 25,
    position: "absolute",
  },
  setPinCode1: {
    top: 204,
    left: 134,
    fontSize: FontSize.size_smi,
    fontFamily: FontFamily.dMSansRegular,
    color: Color.colorGray_100,
    width: 135,
  },
  groupInner: {
    top: 0,
  },
  rectangleView: {
    top: 14,
  },
  set: {
    top: 17,
    left: 43,
    fontSize: FontSize.size_3xl,
    width: 38,
    height: 27,
    color: Color.colorWhite,
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
    textAlign: "left",
  },
  rectangleGroup: {
    top: 717,
    left: 135,
    height: 76,
    width: 123,
    position: "absolute",
  },
  splashScreen15Item: {
    top: 251,
    left: 120,
    width: 154,
    height: 21,
    position: "absolute",
  },
  splashScreen15Inner: {
    top: 328,
    left: 63,
    width: 267,
    height: 332,
    position: "absolute",
  },
  text2: {
    left: 190,
    width: 13,
    color: Color.colorWhite,
  },
  text3: {
    color: Color.colorWhite,
    top: 427,
  },
  text4: {
    top: 517,
    color: Color.colorGray_200,
  },
  text5: {
    top: 608,
    color: Color.colorWhite,
  },
  text6: {
    width: 12,
    top: 337,
    left: 293,
    color: Color.colorGray_200,
  },
  text7: {
    width: 13,
    color: Color.colorWhite,
    top: 427,
  },
  text8: {
    top: 517,
    width: 13,
    color: Color.colorGray_200,
  },
  text9: {
    top: 517,
    width: 13,
    color: Color.colorWhite,
    left: 87,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    height: 44,
    textAlign: "left",
    lineHeight: 42,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  androidFaceIcon: {
    height: "5.05%",
    width: "10.94%",
    top: "71.36%",
    right: "70.99%",
    bottom: "23.59%",
    left: "18.07%",
  },
  androidFingerprintIcon: {
    height: "4.23%",
    width: "9.41%",
    top: "71.83%",
    right: "19.08%",
    bottom: "23.94%",
    left: "71.5%",
  },
  splashScreen15: {
    borderRadius: Border.br_29xl,
    flex: 1,
    width: "100%",
    overflow: "hidden",
    height: 852,
    backgroundColor: Color.colorWhite,
  },
});

export default SplashScreen14;
