import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Border, Color, FontFamily, FontSize } from "../GlobalStyles";

const SplashScreen10 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.splashScreen11}>
      <View style={styles.splashScreen11Child} />
      <Text style={styles.verifyYourNumber}>Verify your Number</Text>
      <Text
        style={[
          styles.pleaseVerifyYourPhoneContainer,
          styles.rectangleGroupLayout,
        ]}
      >
        Please verify yourPhone Number
      </Text>
      <Pressable
        style={styles.rectangleParent}
        onPress={() => navigation.navigate("SplashScreen9")}
      >
        <View style={[styles.groupChild, styles.groupLayout]} />
        <View style={[styles.groupItem, styles.groupLayout]} />
      </Pressable>
      <Image
        style={styles.arrowToTopIcon}
        contentFit="cover"
        source={require("../assets/arrow-to-top.png")}
      />
      <Text style={[styles.enterVerificationCode, styles.textTypo]}>
        Enter Verification Code (5-digit)
      </Text>
      <Text style={[styles.text, styles.textTypo]}>56234</Text>
      <View style={styles.splashScreen11Item} />
      <Pressable
        style={[styles.rectangleGroup, styles.rectangleGroupLayout]}
        onPress={() => navigation.navigate("SplashScreen14")}
      >
        <View style={[styles.groupInner, styles.groupInnerLayout]} />
        <View style={[styles.rectangleView, styles.groupInnerLayout]} />
        <Text style={styles.verify}>Verify</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  rectangleGroupLayout: {
    width: 161,
    position: "absolute",
  },
  groupLayout: {
    height: 36,
    borderRadius: Border.br_xl,
    backgroundColor: Color.colorDeepskyblue,
    width: 66,
    left: 0,
    position: "absolute",
  },
  textTypo: {
    fontFamily: FontFamily.poppinsRegular,
    left: 35,
    textAlign: "left",
    position: "absolute",
  },
  groupInnerLayout: {
    height: 62,
    borderRadius: Border.br_xl,
    width: 161,
    left: 0,
    position: "absolute",
  },
  splashScreen11Child: {
    width: 393,
    left: 0,
    top: 0,
    position: "absolute",
    height: 852,
    backgroundColor: Color.colorWhite,
  },
  verifyYourNumber: {
    top: 37,
    left: 121,
    fontSize: FontSize.size_xl,
    lineHeight: 42,
    color: Color.colorGray_200,
    width: 198,
    height: 44,
    textAlign: "left",
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
    position: "absolute",
  },
  pleaseVerifyYourPhoneContainer: {
    top: 85,
    left: 130,
    fontSize: FontSize.size_base,
    lineHeight: 26,
    fontWeight: "500",
    fontFamily: FontFamily.dMSansMedium,
    color: Color.colorSilver,
    textAlign: "center",
    height: 55,
  },
  groupChild: {
    top: 0,
    borderRadius: Border.br_xl,
  },
  groupItem: {
    top: 8,
  },
  rectangleParent: {
    top: 41,
    left: 37,
    width: 66,
    height: 44,
    position: "absolute",
  },
  arrowToTopIcon: {
    top: 46,
    left: 57,
    width: 25,
    height: 25,
    position: "absolute",
  },
  enterVerificationCode: {
    top: 253,
    fontSize: FontSize.size_xs,
    color: Color.colorGray_100,
    width: 201,
    height: 19,
  },
  text: {
    top: 287,
    fontSize: FontSize.size_sm,
    color: Color.colorBlack,
    width: 45,
    height: 23,
  },
  splashScreen11Item: {
    top: 323,
    borderStyle: "solid",
    borderColor: Color.colorGray_100,
    borderTopWidth: 1,
    width: 325,
    height: 1,
    left: 35,
    position: "absolute",
  },
  groupInner: {
    backgroundColor: Color.colorDeepskyblue,
    height: 62,
    top: 0,
  },
  rectangleView: {
    top: 14,
    backgroundColor: "#5065c0",
  },
  verify: {
    top: 17,
    left: 47,
    fontSize: FontSize.size_3xl,
    color: Color.colorWhite,
    width: 67,
    height: 27,
    textAlign: "left",
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
    position: "absolute",
  },
  rectangleGroup: {
    top: 388,
    left: 117,
    height: 76,
  },
  splashScreen11: {
    borderRadius: Border.br_29xl,
    flex: 1,
    width: "100%",
    overflow: "hidden",
    height: 852,
    backgroundColor: Color.colorWhite,
  },
});

export default SplashScreen10;
