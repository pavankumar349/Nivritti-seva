import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const SplashScreen2 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.splashScreen3}>
      <View style={[styles.splashScreen3Child, styles.sliderIconPosition]} />
      <Pressable
        style={styles.rectangleParent}
        onPress={() => navigation.navigate("SplashScreen3")}
      >
        <View style={[styles.groupChild, styles.groupLayout]} />
        <View style={[styles.groupItem, styles.groupLayout]} />
        <Text style={styles.continue}>Continue</Text>
      </Pressable>
      <Image
        style={[styles.sliderIcon, styles.sliderIconPosition]}
        contentFit="cover"
        source={require("../assets/slider.png")}
      />
      <Text style={styles.fastMoneyTransfer}>
        Fast money transfer and gauranteed safe transactions with others.
      </Text>
      <Image
        style={styles.fastLoadingRafiki1}
        contentFit="cover"
        source={require("../assets/fast-loadingrafiki-1.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  sliderIconPosition: {
    width: 375,
    left: 9,
    position: "absolute",
  },
  groupLayout: {
    height: 59,
    backgroundColor: Color.colorDeepskyblue,
    borderRadius: Border.br_xl,
    left: 0,
    width: 201,
    position: "absolute",
  },
  splashScreen3Child: {
    top: 40,
    height: 812,
    backgroundColor: Color.colorWhite,
  },
  groupChild: {
    top: 0,
  },
  groupItem: {
    top: 13,
  },
  continue: {
    top: 15,
    left: 55,
    fontSize: FontSize.size_3xl,
    fontWeight: "700",
    fontFamily: FontFamily.dMSansBold,
    color: Color.colorWhite,
    textAlign: "left",
    position: "absolute",
  },
  rectangleParent: {
    top: 695,
    left: 96,
    height: 72,
    width: 201,
    position: "absolute",
  },
  sliderIcon: {
    top: 631,
    height: 44,
  },
  fastMoneyTransfer: {
    top: 557,
    left: 60,
    fontSize: FontSize.size_smi,
    fontWeight: "500",
    fontFamily: FontFamily.dMSansMedium,
    color: Color.colorGray_100,
    textAlign: "center",
    width: 272,
    position: "absolute",
  },
  fastLoadingRafiki1: {
    top: 112,
    left: 21,
    width: 350,
    height: 350,
    position: "absolute",
    overflow: "hidden",
  },
  splashScreen3: {
    borderRadius: Border.br_29xl,
    flex: 1,
    width: "100%",
    height: 852,
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
  },
});

export default SplashScreen2;
