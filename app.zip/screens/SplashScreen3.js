import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const SplashScreen3 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.splashScreen4}>
      <View style={[styles.splashScreen4Child, styles.sliderIconPosition]} />
      <Pressable
        style={styles.rectangleParent}
        onPress={() => navigation.navigate("SplashScreen4")}
      >
        <View style={[styles.groupChild, styles.groupLayout]} />
        <View style={[styles.groupItem, styles.groupLayout]} />
        <Text style={[styles.continue, styles.continueTypo]}>Continue</Text>
      </Pressable>
      <Text style={[styles.savingYourMoney, styles.continueTypo]}>
        Saving Your Money
      </Text>
      <Text style={styles.trackTheProgressContainer}>
        <Text style={styles.trackTheProgress}>
          Track the progress of your savings
        </Text>
        <Text>
          <Text style={styles.trackTheProgress}>{`with `}</Text>
          <Text style={styles.nivrittiseva}>NivrittiSeva.</Text>
        </Text>
      </Text>
      <Image
        style={[styles.sliderIcon, styles.sliderIconPosition]}
        contentFit="cover"
        source={require("../assets/slider1.png")}
      />
      <Image
        style={styles.savingsPana1Icon}
        contentFit="cover"
        source={require("../assets/savingspana-1.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  sliderIconPosition: {
    width: 375,
    left: 9,
    position: "absolute",
  },
  groupLayout: {
    height: 59,
    backgroundColor: Color.colorDeepskyblue,
    borderRadius: Border.br_xl,
    left: 0,
    width: 201,
    position: "absolute",
  },
  continueTypo: {
    textAlign: "left",
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
    position: "absolute",
  },
  splashScreen4Child: {
    top: 40,
    height: 812,
    backgroundColor: Color.colorWhite,
  },
  groupChild: {
    top: 0,
  },
  groupItem: {
    top: 13,
  },
  continue: {
    top: 15,
    left: 55,
    fontSize: FontSize.size_3xl,
    color: Color.colorWhite,
  },
  rectangleParent: {
    top: 695,
    left: 96,
    height: 72,
    width: 201,
    position: "absolute",
  },
  savingYourMoney: {
    top: 484,
    left: 46,
    fontSize: FontSize.size_16xl,
    lineHeight: 51,
    color: Color.colorGray_200,
    width: 317,
  },
  trackTheProgress: {
    color: Color.colorGray_100,
  },
  nivrittiseva: {
    color: Color.colorDeepskyblue,
  },
  trackTheProgressContainer: {
    top: 557,
    left: 91,
    fontSize: FontSize.size_smi,
    fontWeight: "500",
    fontFamily: FontFamily.dMSansMedium,
    textAlign: "center",
    position: "absolute",
  },
  sliderIcon: {
    top: 631,
    height: 44,
  },
  savingsPana1Icon: {
    top: 135,
    left: 29,
    width: 334,
    height: 334,
    position: "absolute",
    overflow: "hidden",
  },
  splashScreen4: {
    borderRadius: Border.br_29xl,
    flex: 1,
    width: "100%",
    height: 852,
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
  },
});

export default SplashScreen3;
