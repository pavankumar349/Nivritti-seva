import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import GroupComponent from "../components/GroupComponent";
import { FontFamily, Color, Border, FontSize } from "../GlobalStyles";

const SplashScreen9 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.splashScreen10}>
      <View style={styles.splashScreen10Child} />
      <Text style={styles.phoneNumber}>Phone Number</Text>
      <Text
        style={[styles.pleaseAddYour, styles.phoneNumber1Typo]}
      >{`Please add your
mobile phone number`}</Text>
      <Pressable
        style={styles.rectangleParent}
        onPress={() => navigation.navigate("SplashScreen8")}
      >
        <View style={[styles.groupChild, styles.groupLayout]} />
        <View style={[styles.groupItem, styles.groupLayout]} />
      </Pressable>
      <Image
        style={styles.arrowToTopIcon}
        contentFit="cover"
        source={require("../assets/arrow-to-top.png")}
      />
      <Text style={[styles.phoneNumber1, styles.textPosition]}>
        * Phone Number
      </Text>
      <View style={[styles.splashScreen10Item, styles.textPosition]} />
      <GroupComponent
        propBackgroundColor="#38b6ff"
        onGroupPressablePress={() => navigation.navigate("SplashScreen10")}
      />
      <View style={styles.splashScreen10Inner} />
      <Image
        style={styles.groupIcon}
        contentFit="cover"
        source={require("../assets/group-21.png")}
      />
      <Text style={[styles.text, styles.textPosition]}>+91 9965874215</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  phoneNumber1Typo: {
    fontFamily: FontFamily.dMSansMedium,
    fontWeight: "500",
  },
  groupLayout: {
    height: 36,
    backgroundColor: Color.colorDeepskyblue,
    borderRadius: Border.br_xl,
    width: 66,
    left: 0,
    position: "absolute",
  },
  textPosition: {
    left: 35,
    position: "absolute",
  },
  splashScreen10Child: {
    width: 393,
    height: 851,
    left: 0,
    top: 0,
    position: "absolute",
    backgroundColor: Color.colorWhite,
  },
  phoneNumber: {
    top: 37,
    left: 127,
    fontSize: FontSize.size_xl,
    lineHeight: 42,
    fontWeight: "700",
    fontFamily: FontFamily.dMSansBold,
    color: Color.colorGray_200,
    width: 167,
    height: 44,
    textAlign: "left",
    position: "absolute",
  },
  pleaseAddYour: {
    top: 85,
    left: 97,
    fontSize: FontSize.size_base,
    lineHeight: 26,
    color: Color.colorSilver,
    textAlign: "center",
    width: 199,
    height: 55,
    position: "absolute",
  },
  groupChild: {
    top: 0,
    height: 36,
  },
  groupItem: {
    top: 8,
  },
  rectangleParent: {
    top: 41,
    left: 37,
    width: 66,
    height: 44,
    position: "absolute",
  },
  arrowToTopIcon: {
    top: 46,
    left: 57,
    width: 25,
    height: 25,
    position: "absolute",
  },
  phoneNumber1: {
    top: 253,
    fontSize: FontSize.size_xs,
    color: Color.colorDeepskyblue,
    width: 101,
    fontFamily: FontFamily.dMSansMedium,
    fontWeight: "500",
    textAlign: "left",
    left: 35,
  },
  splashScreen10Item: {
    top: 323,
    borderStyle: "solid",
    borderColor: Color.colorMediumslateblue,
    borderTopWidth: 1,
    width: 324,
    height: 1,
  },
  splashScreen10Inner: {
    top: 289,
    left: 340,
    width: 18,
    height: 19,
    backgroundColor: Color.colorDeepskyblue,
    borderRadius: Border.br_xl,
    position: "absolute",
  },
  groupIcon: {
    top: 296,
    left: 345,
    width: 8,
    height: 6,
    position: "absolute",
  },
  text: {
    top: 287,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.dMSansRegular,
    color: Color.colorBlack,
    width: 147,
    height: 18,
    textAlign: "left",
    left: 35,
  },
  splashScreen10: {
    borderRadius: Border.br_29xl,
    flex: 1,
    width: "100%",
    height: 852,
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
  },
});

export default SplashScreen9;
