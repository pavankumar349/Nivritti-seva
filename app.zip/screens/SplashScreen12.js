import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const SplashScreen12 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.splashScreen13}>
      <View style={styles.splashScreen13Child} />
      <Text style={styles.securityQuestions}>Security Questions</Text>
      <Pressable
        style={styles.rectangleParent}
        onPress={() => navigation.navigate("SplashScreen11")}
      >
        <View style={[styles.groupChild, styles.groupLayout]} />
        <View style={[styles.groupItem, styles.groupLayout]} />
      </Pressable>
      <Image
        style={styles.arrowToTopIcon}
        contentFit="cover"
        source={require("../assets/arrow-to-top.png")}
      />
      <Pressable
        style={styles.rectangleGroup}
        onPress={() => navigation.navigate("SplashScreen13")}
      >
        <View style={[styles.groupInner, styles.groupInnerLayout]} />
        <View style={[styles.rectangleView, styles.groupInnerLayout]} />
        <Text style={[styles.save, styles.saveFlexBox]}>Save</Text>
      </Pressable>
      <View style={styles.splashScreen13Item} />
      <Text style={[styles.writeYourAnswer, styles.saveFlexBox]}>
        Write your answer here...
      </Text>
      <Text
        style={[styles.whatWasYourFirstContainer, styles.pleaseWriteAPosition]}
      >
        What was yourFirst School’s{`Name? `}
      </Text>
      <Text style={[styles.pleaseWriteA, styles.pleaseWriteAPosition]}>
        Please, write a short answer in the field below.
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  groupLayout: {
    height: 36,
    backgroundColor: Color.colorDeepskyblue,
    borderRadius: Border.br_xl,
    width: 66,
    left: 0,
    position: "absolute",
  },
  groupInnerLayout: {
    height: 62,
    borderRadius: Border.br_31xl,
    width: 161,
    backgroundColor: Color.colorDeepskyblue,
    left: 0,
    position: "absolute",
  },
  saveFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  pleaseWriteAPosition: {
    left: 31,
    textAlign: "left",
    position: "absolute",
  },
  splashScreen13Child: {
    width: 393,
    left: 0,
    top: 0,
    position: "absolute",
    height: 852,
    backgroundColor: Color.colorWhite,
  },
  securityQuestions: {
    top: 37,
    left: 122,
    fontSize: FontSize.size_xl,
    lineHeight: 42,
    color: Color.colorGray_200,
    width: 212,
    height: 44,
    textAlign: "left",
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
    position: "absolute",
  },
  groupChild: {
    top: 0,
  },
  groupItem: {
    top: 8,
  },
  rectangleParent: {
    top: 41,
    left: 37,
    width: 66,
    height: 44,
    position: "absolute",
  },
  arrowToTopIcon: {
    top: 46,
    left: 57,
    width: 25,
    height: 25,
    position: "absolute",
  },
  groupInner: {
    top: 0,
  },
  rectangleView: {
    top: 14,
  },
  save: {
    top: 18,
    left: 53,
    fontSize: FontSize.size_3xl,
    color: Color.colorWhite,
    width: 54,
    height: 27,
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
  },
  rectangleGroup: {
    top: 718,
    left: 118,
    height: 76,
    width: 161,
    position: "absolute",
  },
  splashScreen13Item: {
    top: 366,
    left: 17,
    borderRadius: Border.br_3xs,
    backgroundColor: Color.colorMidnightblue,
    width: 360,
    height: 116,
    opacity: 0.05,
    position: "absolute",
  },
  writeYourAnswer: {
    top: 380,
    left: 36,
    lineHeight: 21,
    fontWeight: "500",
    fontFamily: FontFamily.dMSansMedium,
    color: "rgba(81, 100, 191, 0.9)",
    width: 171,
    height: 22,
    fontSize: FontSize.size_mini,
  },
  whatWasYourFirstContainer: {
    top: 115,
    fontSize: 44,
    lineHeight: 52,
    color: Color.colorDeepskyblue,
    width: 316,
    height: 164,
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
  },
  pleaseWriteA: {
    top: 304,
    fontFamily: FontFamily.dMSansRegular,
    color: Color.colorGray_100,
    width: 359,
    height: 19,
    fontSize: FontSize.size_mini,
  },
  splashScreen13: {
    borderRadius: Border.br_29xl,
    flex: 1,
    width: "100%",
    overflow: "hidden",
    height: 852,
    backgroundColor: Color.colorWhite,
  },
});

export default SplashScreen12;
