import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Color, Border, FontSize } from "../GlobalStyles";

const SplashScreen6 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.splashScreen7}>
      <View style={styles.splashScreen7Child} />
      <Pressable
        style={styles.rectangleParent}
        onPress={() => navigation.navigate("SplashScreen7")}
      >
        <View style={[styles.groupChild, styles.groupLayout]} />
        <View style={[styles.groupItem, styles.groupLayout]} />
        <Text style={[styles.signUp, styles.signTypo]}>Sign Up</Text>
      </Pressable>
      <Text style={[styles.signUp1, styles.signTypo]}>
        <Text style={styles.blankLine}> </Text>
        <Text style={styles.signUp2}>Sign Up</Text>
      </Text>
      <Text style={[styles.emailAddress, styles.emailAddressTypo]}>
        Email Address
      </Text>
      <Text style={[styles.alreadyHaveAnContainer, styles.emailAddressTypo]}>
        <Text style={styles.alreadyHaveAn}>Already have an account?</Text>
        <Text style={styles.text}>{` `}</Text>
        <Text style={styles.text}>
          <Text style={styles.login1}>Login</Text>
        </Text>
      </Text>
      <Text style={[styles.mainideasgmailcom, styles.orTypo]}>
        Mainideas@gmail.com
      </Text>
      <Text style={styles.password}>Password</Text>
      <Text style={[styles.confirmPassword, styles.emailAddressTypo]}>
        Confirm Password
      </Text>
      <Text style={[styles.or, styles.orTypo]}>or</Text>
      <View style={styles.splashScreen7Item} />
      <View style={[styles.splashScreen7Inner, styles.lineViewBorder]} />
      <View style={[styles.lineView, styles.lineViewBorder]} />
      <View style={[styles.splashScreen7Child1, styles.splashChildLayout]} />
      <View style={[styles.splashScreen7Child2, styles.splashChildLayout]} />
      <View style={[styles.rectangleView, styles.groupLayout]} />
      <Image
        style={styles.googleIcon}
        contentFit="cover"
        source={require("../assets/google.png")}
      />
      <Image
        style={styles.maskGroupIcon}
        contentFit="cover"
        source={require("../assets/mask-group3.png")}
      />
      <Image
        style={styles.groupIcon}
        contentFit="cover"
        source={require("../assets/group-57.png")}
      />
      <Image
        style={[styles.maskGroupIcon1, styles.maskGroupLayout]}
        contentFit="cover"
        source={require("../assets/mask-group4.png")}
      />
      <Image
        style={[styles.maskGroupIcon2, styles.maskGroupLayout]}
        contentFit="cover"
        source={require("../assets/mask-group5.png")}
      />
      <Image
        style={styles.splashScreen7Child3}
        contentFit="cover"
        source={require("../assets/group-911.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  groupLayout: {
    height: 63,
    position: "absolute",
  },
  signTypo: {
    textAlign: "left",
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
    position: "absolute",
  },
  emailAddressTypo: {
    height: 18,
    fontFamily: FontFamily.dMSansMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  orTypo: {
    height: 20,
    fontFamily: FontFamily.dMSansMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  lineViewBorder: {
    borderColor: Color.colorDarkgray,
    height: 1,
    width: 333,
    borderTopWidth: 1,
    borderStyle: "solid",
    left: 36,
    position: "absolute",
  },
  splashChildLayout: {
    width: 86,
    top: 662,
    borderColor: Color.colorDarkgray,
    height: 1,
    borderTopWidth: 1,
    borderStyle: "solid",
    position: "absolute",
  },
  maskGroupLayout: {
    height: 14,
    width: 14,
    left: 349,
    position: "absolute",
  },
  splashScreen7Child: {
    width: 403,
    height: 873,
    left: 0,
    top: 0,
    position: "absolute",
    backgroundColor: Color.colorWhite,
  },
  groupChild: {
    backgroundColor: Color.colorDeepskyblue,
    borderRadius: Border.br_xl,
    height: 63,
    width: 216,
    left: 0,
    top: 0,
  },
  groupItem: {
    top: 14,
    backgroundColor: Color.colorDeepskyblue,
    borderRadius: Border.br_xl,
    height: 63,
    width: 216,
    left: 0,
  },
  signUp: {
    top: 17,
    left: 67,
    fontSize: FontSize.size_3xl,
    color: Color.colorWhite,
    width: 82,
    height: 28,
  },
  rectangleParent: {
    top: 546,
    left: 94,
    height: 77,
    width: 216,
    position: "absolute",
  },
  blankLine: {
    color: Color.colorMediumslateblue,
  },
  signUp2: {
    color: Color.colorGray_200,
  },
  signUp1: {
    top: 79,
    fontSize: FontSize.size_21xl,
    lineHeight: 42,
    width: 150,
    height: 90,
    left: 36,
  },
  emailAddress: {
    top: 222,
    width: 102,
    color: Color.colorDeepskyblue,
    fontSize: FontSize.size_smi,
    height: 18,
    left: 36,
  },
  alreadyHaveAn: {
    color: Color.colorGray_100,
  },
  text: {
    color: Color.colorDeepskyblue,
  },
  login1: {
    textDecoration: "underline",
  },
  alreadyHaveAnContainer: {
    top: 800,
    left: 97,
    fontSize: FontSize.size_sm,
    width: 208,
  },
  mainideasgmailcom: {
    top: 258,
    fontSize: FontSize.size_mini,
    width: 174,
    color: Color.colorGray_200,
    left: 36,
  },
  password: {
    top: 322,
    width: 59,
    height: 17,
    color: Color.colorGray_100,
    fontFamily: FontFamily.dMSansMedium,
    fontWeight: "500",
    fontSize: FontSize.size_smi,
    left: 36,
    textAlign: "left",
    position: "absolute",
  },
  confirmPassword: {
    top: 420,
    width: 113,
    color: Color.colorGray_100,
    fontSize: FontSize.size_smi,
    height: 18,
    left: 36,
  },
  or: {
    top: 651,
    left: 194,
    fontSize: FontSize.size_base,
    color: Color.colorDarkgray,
    width: 16,
  },
  splashScreen7Item: {
    top: 294,
    borderColor: Color.colorMediumslateblue,
    height: 1,
    width: 333,
    borderTopWidth: 1,
    borderStyle: "solid",
    left: 36,
    position: "absolute",
  },
  splashScreen7Inner: {
    top: 393,
  },
  lineView: {
    top: 493,
  },
  splashScreen7Child1: {
    left: 93,
  },
  splashScreen7Child2: {
    left: 224,
  },
  rectangleView: {
    top: 689,
    left: 114,
    borderRadius: Border.br_31xl,
    backgroundColor: Color.colorWhitesmoke,
    width: 64,
  },
  googleIcon: {
    top: 703,
    left: 129,
    width: 34,
    height: 35,
    position: "absolute",
    overflow: "hidden",
  },
  maskGroupIcon: {
    top: 688,
    left: 225,
    width: 65,
    height: 65,
    position: "absolute",
  },
  groupIcon: {
    top: 259,
    left: 348,
    width: 19,
    height: 19,
    position: "absolute",
  },
  maskGroupIcon1: {
    top: 363,
  },
  maskGroupIcon2: {
    top: 462,
  },
  splashScreen7Child3: {
    top: 58,
    width: 84,
    height: 51,
    left: 36,
    position: "absolute",
  },
  splashScreen7: {
    borderRadius: Border.br_29xl,
    flex: 1,
    width: "100%",
    height: 852,
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
  },
});

export default SplashScreen6;
