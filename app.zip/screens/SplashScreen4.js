import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Border, FontFamily, Color, FontSize } from "../GlobalStyles";

const SplashScreen4 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.splashScreen5}>
      <View style={[styles.splashScreen5Child, styles.sliderIconPosition]} />
      <Pressable
        style={styles.rectangleParent}
        onPress={() => navigation.navigate("SplashScreen5")}
      >
        <View style={[styles.groupChild, styles.groupLayout]} />
        <View style={[styles.groupItem, styles.groupLayout]} />
        <Text style={[styles.continue, styles.continueTypo]}>Continue</Text>
      </Pressable>
      <Text style={[styles.billsPaymentMade, styles.billsPaymentMadeFlexBox]}>
        Bills Payment Made Easy
      </Text>
      <Text
        style={[styles.payMonthlyOrContainer, styles.billsPaymentMadeFlexBox]}
      >
        <Text style={styles.payMonthlyOr}>
          Pay monthly or daily bills at home
        </Text>
        <Text>
          <Text style={styles.payMonthlyOr}>{`with `}</Text>
          <Text style={styles.nivrittiseva}>NivrittiSeva</Text>
          <Text style={styles.payMonthlyOr}>.</Text>
        </Text>
      </Text>
      <Image
        style={[styles.sliderIcon, styles.sliderIconPosition]}
        contentFit="cover"
        source={require("../assets/slider2.png")}
      />
      <Image
        style={styles.plainCreditCardPana1}
        contentFit="cover"
        source={require("../assets/plain-credit-cardpana-1.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  sliderIconPosition: {
    width: 375,
    left: 9,
    position: "absolute",
  },
  groupLayout: {
    height: 59,
    borderRadius: Border.br_xl,
    left: 0,
    width: 201,
    position: "absolute",
  },
  continueTypo: {
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
  },
  billsPaymentMadeFlexBox: {
    textAlign: "center",
    position: "absolute",
  },
  splashScreen5Child: {
    top: 40,
    height: 812,
    backgroundColor: Color.colorWhite,
  },
  groupChild: {
    top: 0,
    backgroundColor: Color.colorDeepskyblue,
  },
  groupItem: {
    top: 13,
    backgroundColor: Color.colorRoyalblue_100,
  },
  continue: {
    top: 15,
    left: 55,
    fontSize: FontSize.size_3xl,
    color: Color.colorWhite,
    textAlign: "left",
    position: "absolute",
  },
  rectangleParent: {
    top: 695,
    left: 96,
    height: 72,
    width: 201,
    position: "absolute",
  },
  billsPaymentMade: {
    top: 467,
    left: 47,
    fontSize: FontSize.size_16xl,
    lineHeight: 40,
    color: Color.colorGray_200,
    width: 299,
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
  },
  payMonthlyOr: {
    color: Color.colorGray_100,
  },
  nivrittiseva: {
    color: Color.colorDeepskyblue,
  },
  payMonthlyOrContainer: {
    top: 558,
    left: 93,
    fontSize: FontSize.size_smi,
    fontWeight: "500",
    fontFamily: FontFamily.dMSansMedium,
  },
  sliderIcon: {
    top: 631,
    height: 44,
  },
  plainCreditCardPana1: {
    top: 114,
    left: 25,
    width: 342,
    height: 342,
    position: "absolute",
    overflow: "hidden",
  },
  splashScreen5: {
    borderRadius: Border.br_29xl,
    flex: 1,
    width: "100%",
    height: 852,
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
  },
});

export default SplashScreen4;
