import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const SplashScreen1 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.splashScreen2}>
      <View style={styles.splashScreen2Child} />
      <Pressable
        style={styles.rectangleParent}
        onPress={() => navigation.navigate("SplashScreen2")}
      >
        <View style={[styles.groupChild, styles.groupLayout]} />
        <View style={[styles.groupItem, styles.groupLayout]} />
        <Text style={[styles.getStarted, styles.getStartedFlexBox]}>
          Get Started
        </Text>
      </Pressable>
      <Text style={[styles.welcomeToNivrittiseva, styles.getStartedTypo]}>
        <Text>
          <Text style={styles.welcomeTo}>
            <Text style={styles.welcomeTo1}>Welcome to</Text>
          </Text>
        </Text>
        <Text style={styles.nivrittiseva}>NivrittiSeva.</Text>
      </Text>
      <Text style={[styles.yourBestMoney, styles.getStartedFlexBox]}>
        Your Best Money Transfer Partner.
      </Text>
      <Image
        style={styles.image8Icon}
        contentFit="cover"
        source={require("../assets/image-7.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  groupLayout: {
    height: 59,
    backgroundColor: Color.colorDeepskyblue,
    borderRadius: Border.br_xl,
    width: 201,
    left: 0,
    position: "absolute",
  },
  getStartedFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  getStartedTypo: {
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
  },
  splashScreen2Child: {
    width: 375,
    height: 812,
    left: 0,
    top: 0,
    position: "absolute",
    backgroundColor: Color.colorWhite,
  },
  groupChild: {
    top: 0,
    backgroundColor: Color.colorDeepskyblue,
    borderRadius: Border.br_xl,
  },
  groupItem: {
    top: 13,
  },
  getStarted: {
    top: 16,
    left: 44,
    fontSize: FontSize.size_3xl,
    color: Color.colorWhite,
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
  },
  rectangleParent: {
    top: 655,
    left: 87,
    height: 72,
    width: 201,
    position: "absolute",
  },
  welcomeTo1: {
    fontSize: 45,
  },
  welcomeTo: {
    color: Color.colorGray_200,
  },
  nivrittiseva: {
    fontSize: 36,
    color: Color.colorDeepskyblue,
  },
  welcomeToNivrittiseva: {
    top: 406,
    left: 56,
    lineHeight: 47,
    textAlign: "center",
    position: "absolute",
  },
  yourBestMoney: {
    top: 528,
    left: 91,
    fontSize: FontSize.size_smi,
    fontWeight: "500",
    fontFamily: FontFamily.dMSansMedium,
    color: Color.colorGray_100,
  },
  image8Icon: {
    marginLeft: -135.5,
    top: 193,
    left: "50%",
    width: 253,
    height: 188,
    position: "absolute",
  },
  splashScreen2: {
    borderRadius: Border.br_29xl,
    flex: 1,
    width: "100%",
    height: 852,
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
  },
});

export default SplashScreen1;
