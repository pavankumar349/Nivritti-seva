import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const SplashScreen15 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.splashScreen16}>
      <View style={styles.splashScreen16Child} />
      <Text style={styles.login}>Login</Text>
      <Text style={[styles.text, styles.textTypo3]}>1</Text>
      <Text style={[styles.text1, styles.textTypo2]}>4</Text>
      <Text
        style={[
          styles.pleaseEnterYourPinContainer,
          styles.splashScreen16ItemPosition,
        ]}
      >
        Please enter yourPin Code
      </Text>
      <Pressable
        style={styles.rectangleParent}
        onPress={() => navigation.navigate("SplashScreen12")}
      >
        <View style={[styles.groupChild, styles.groupLayout]} />
        <View style={[styles.groupItem, styles.groupLayout]} />
      </Pressable>
      <Image
        style={styles.arrowToTopIcon}
        contentFit="cover"
        source={require("../assets/arrow-to-top.png")}
      />
      <Text style={[styles.enterPinCode, styles.goFlexBox]}>
        Enter Pin Code (5-digit)
      </Text>
      <View style={styles.rectangleGroup}>
        <View style={[styles.groupInner, styles.groupInnerLayout]} />
        <View style={[styles.rectangleView, styles.groupInnerLayout]} />
        <Text style={[styles.go, styles.goFlexBox]}>Go</Text>
      </View>
      <Image
        style={[styles.splashScreen16Item, styles.splashScreen16ItemPosition]}
        contentFit="cover"
        source={require("../assets/group-51.png")}
      />
      <Image
        style={styles.splashScreen16Inner}
        contentFit="cover"
        source={require("../assets/group-61.png")}
      />
      <Text style={[styles.text2, styles.textTypo3]}>2</Text>
      <Text style={[styles.text3, styles.textTypo1]}>5</Text>
      <Text style={[styles.text4, styles.textTypo1]}>8</Text>
      <Text style={[styles.text5, styles.textTypo1]}>0</Text>
      <Text style={[styles.text6, styles.textTypo]}>3</Text>
      <Text style={[styles.text7, styles.textTypo]}>6</Text>
      <Text style={[styles.text8, styles.textTypo]}>9</Text>
      <Text style={[styles.text9, styles.textTypo2]}>7</Text>
      <Image
        style={[styles.androidFaceIcon, styles.androidIconLayout]}
        contentFit="cover"
        source={require("../assets/android-face.png")}
      />
      <Image
        style={[styles.androidFingerprintIcon, styles.androidIconLayout]}
        contentFit="cover"
        source={require("../assets/android-fingerprint1.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  textTypo3: {
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    top: 336,
    height: 44,
    textAlign: "left",
    lineHeight: 42,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  textTypo2: {
    left: 87,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    height: 44,
    textAlign: "left",
    color: Color.colorGray_200,
    lineHeight: 42,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  splashScreen16ItemPosition: {
    left: 120,
    position: "absolute",
  },
  groupLayout: {
    height: 36,
    borderRadius: Border.br_xl,
    width: 66,
    left: 0,
    position: "absolute",
  },
  goFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  groupInnerLayout: {
    height: 62,
    borderRadius: Border.br_31xl,
    width: 123,
    backgroundColor: Color.colorDeepskyblue,
    left: 0,
    position: "absolute",
  },
  textTypo1: {
    left: 189,
    width: 13,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    height: 44,
    textAlign: "left",
    lineHeight: 42,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  textTypo: {
    left: 292,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    height: 44,
    textAlign: "left",
    color: Color.colorGray_200,
    lineHeight: 42,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  androidIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  splashScreen16Child: {
    width: 393,
    height: 851,
    left: 0,
    top: 0,
    position: "absolute",
    backgroundColor: Color.colorWhite,
  },
  login: {
    top: 37,
    left: 171,
    width: 52,
    height: 44,
    lineHeight: 42,
    fontSize: FontSize.size_xl,
    textAlign: "left",
    color: Color.colorGray_200,
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
    position: "absolute",
  },
  text: {
    left: 90,
    width: 7,
    color: Color.colorGray_200,
  },
  text1: {
    width: 14,
    top: 427,
  },
  pleaseEnterYourPinContainer: {
    top: 85,
    fontSize: FontSize.size_base,
    lineHeight: 26,
    fontFamily: FontFamily.dMSansMedium,
    color: Color.colorSilver,
    textAlign: "center",
    width: 153,
    height: 55,
    fontWeight: "500",
    left: 120,
  },
  groupChild: {
    backgroundColor: Color.colorDeepskyblue,
    height: 36,
    borderRadius: Border.br_xl,
    top: 0,
  },
  groupItem: {
    top: 8,
    backgroundColor: "#5165bf",
    height: 36,
    borderRadius: Border.br_xl,
  },
  rectangleParent: {
    top: 41,
    left: 37,
    width: 66,
    height: 44,
    position: "absolute",
  },
  arrowToTopIcon: {
    top: 46,
    left: 57,
    width: 25,
    height: 25,
    position: "absolute",
  },
  enterPinCode: {
    top: 203,
    left: 129,
    fontSize: FontSize.size_smi,
    fontFamily: FontFamily.dMSansRegular,
    color: Color.colorGray_100,
    width: 145,
    height: 17,
  },
  groupInner: {
    top: 0,
    height: 62,
    borderRadius: Border.br_31xl,
  },
  rectangleView: {
    top: 14,
  },
  go: {
    top: 17,
    left: 47,
    fontSize: FontSize.size_3xl,
    width: 30,
    height: 27,
    color: Color.colorWhite,
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
    textAlign: "left",
  },
  rectangleGroup: {
    top: 716,
    left: 135,
    height: 75,
    width: 123,
    position: "absolute",
  },
  splashScreen16Item: {
    top: 251,
    width: 154,
    height: 21,
  },
  splashScreen16Inner: {
    top: 328,
    left: 63,
    width: 266,
    height: 331,
    position: "absolute",
  },
  text2: {
    left: 190,
    width: 12,
    color: Color.colorWhite,
  },
  text3: {
    width: 13,
    top: 427,
    color: Color.colorGray_200,
  },
  text4: {
    top: 517,
    width: 13,
    color: Color.colorGray_200,
  },
  text5: {
    top: 607,
    width: 13,
    color: Color.colorWhite,
  },
  text6: {
    width: 13,
    top: 336,
    left: 292,
  },
  text7: {
    width: 14,
    top: 427,
  },
  text8: {
    top: 517,
    width: 14,
  },
  text9: {
    top: 517,
    width: 13,
  },
  androidFaceIcon: {
    height: "5.05%",
    width: "10.94%",
    top: "71.24%",
    right: "70.99%",
    bottom: "23.71%",
    left: "18.07%",
  },
  androidFingerprintIcon: {
    height: "4.34%",
    width: "9.41%",
    top: "71.71%",
    right: "19.08%",
    bottom: "23.94%",
    left: "71.5%",
  },
  splashScreen16: {
    borderRadius: Border.br_29xl,
    flex: 1,
    width: "100%",
    height: 852,
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
  },
});

export default SplashScreen15;
