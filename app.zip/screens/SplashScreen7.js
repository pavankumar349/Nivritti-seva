import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Border, Color, FontSize } from "../GlobalStyles";

const SplashScreen7 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.splashScreen8}>
      <View style={styles.splashScreen8Child} />
      <Text style={[styles.profile, styles.profileLayout]}>Profile</Text>
      <Text style={[styles.pleaseSetUp, styles.setTypo]}>
        Please set up your profile
      </Text>
      <Pressable
        style={styles.rectangleParent}
        onPress={() => navigation.navigate("SplashScreen6")}
      >
        <View style={[styles.groupChild, styles.groupLayout1]} />
        <View style={[styles.groupItem, styles.groupLayout1]} />
      </Pressable>
      <Image
        style={[styles.arrowToTopIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/arrow-to-top.png")}
      />
      <Image
        style={styles.splashScreen8Item}
        contentFit="cover"
        source={require("../assets/ellipse-85.png")}
      />
      <Image
        style={[styles.uploadIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/upload.png")}
      />
      <Text style={[styles.firstName, styles.nameTypo]}>First Name</Text>
      <Text style={[styles.micheal, styles.starcTypo]}>Micheal</Text>
      <Text style={[styles.starc, styles.starcTypo]}>Starc</Text>
      <Text style={[styles.lastName, styles.nameTypo]}>Last Name</Text>
      <View style={[styles.splashScreen8Inner, styles.lineViewLayout]} />
      <View style={[styles.lineView, styles.lineViewLayout]} />
      <View style={[styles.rectangleView, styles.rectangleViewLayout]} />
      <View style={[styles.splashScreen8Child1, styles.rectangleViewLayout]} />
      <Image
        style={[styles.groupIcon, styles.groupIconLayout]}
        contentFit="cover"
        source={require("../assets/group-2.png")}
      />
      <Image
        style={[styles.splashScreen8Child2, styles.groupIconLayout]}
        contentFit="cover"
        source={require("../assets/group-3.png")}
      />
      <Pressable
        style={styles.rectangleGroup}
        onPress={() => navigation.navigate("SplashScreen8")}
      >
        <View style={[styles.groupInner, styles.groupLayout]} />
        <View style={[styles.groupChild1, styles.groupLayout]} />
        <Text style={[styles.set, styles.setTypo]}>Set</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  profileLayout: {
    height: 44,
    lineHeight: 42,
  },
  setTypo: {
    fontFamily: FontFamily.dMSansMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  groupLayout1: {
    height: 36,
    borderRadius: Border.br_xl,
    width: 66,
    left: 0,
    position: "absolute",
  },
  iconLayout: {
    height: 25,
    position: "absolute",
  },
  nameTypo: {
    height: 17,
    width: 78,
    color: Color.colorDeepskyblue,
    fontSize: FontSize.size_smi,
    left: 35,
    fontFamily: FontFamily.dMSansMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  starcTypo: {
    fontSize: FontSize.size_sm,
    left: 35,
    fontFamily: FontFamily.dMSansMedium,
    fontWeight: "500",
    textAlign: "left",
    color: Color.colorGray_200,
    position: "absolute",
  },
  lineViewLayout: {
    height: 1,
    width: 324,
    borderTopWidth: 1,
    borderColor: Color.colorDeepskyblue,
    borderStyle: "solid",
    left: 35,
    position: "absolute",
  },
  rectangleViewLayout: {
    height: 19,
    width: 18,
    left: 340,
    backgroundColor: Color.colorDeepskyblue,
    borderRadius: Border.br_xl,
    position: "absolute",
  },
  groupIconLayout: {
    height: 6,
    width: 8,
    left: 345,
    position: "absolute",
  },
  groupLayout: {
    height: 62,
    width: 139,
    borderRadius: Border.br_xl,
    left: 0,
    position: "absolute",
  },
  splashScreen8Child: {
    width: 393,
    height: 851,
    left: 0,
    top: 0,
    position: "absolute",
    backgroundColor: Color.colorWhite,
  },
  profile: {
    top: 37,
    left: 166,
    fontSize: FontSize.size_xl,
    fontWeight: "700",
    fontFamily: FontFamily.dMSansBold,
    width: 80,
    textAlign: "left",
    color: Color.colorGray_200,
    height: 44,
    lineHeight: 42,
    position: "absolute",
  },
  pleaseSetUp: {
    top: 114,
    left: 104,
    fontSize: FontSize.size_base,
    color: Color.colorSilver,
    width: 214,
    height: 44,
    lineHeight: 42,
    fontWeight: "500",
  },
  groupChild: {
    backgroundColor: Color.colorDeepskyblue,
    top: 0,
  },
  groupItem: {
    top: 8,
    backgroundColor: Color.colorRoyalblue_100,
  },
  rectangleParent: {
    top: 41,
    left: 37,
    width: 66,
    height: 44,
    position: "absolute",
  },
  arrowToTopIcon: {
    top: 46,
    left: 57,
    width: 25,
  },
  splashScreen8Item: {
    top: 188,
    left: 126,
    width: 140,
    height: 140,
    position: "absolute",
  },
  uploadIcon: {
    top: 245,
    left: 183,
    width: 26,
  },
  firstName: {
    top: 394,
  },
  micheal: {
    top: 429,
    width: 64,
  },
  starc: {
    top: 525,
    width: 51,
    height: 18,
  },
  lastName: {
    top: 490,
  },
  splashScreen8Inner: {
    top: 464,
  },
  lineView: {
    top: 561,
  },
  rectangleView: {
    top: 431,
  },
  splashScreen8Child1: {
    top: 527,
  },
  groupIcon: {
    top: 438,
  },
  splashScreen8Child2: {
    top: 534,
  },
  groupInner: {
    backgroundColor: Color.colorDeepskyblue,
    top: 0,
  },
  groupChild1: {
    top: 14,
    backgroundColor: Color.colorRoyalblue_100,
  },
  set: {
    top: 17,
    left: 52,
    fontSize: FontSize.size_3xl,
    color: Color.colorWhite,
    width: 35,
    height: 27,
  },
  rectangleGroup: {
    top: 612,
    left: 127,
    height: 75,
    width: 139,
    position: "absolute",
  },
  splashScreen8: {
    borderRadius: Border.br_29xl,
    flex: 1,
    width: "100%",
    height: 852,
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
  },
});

export default SplashScreen7;
