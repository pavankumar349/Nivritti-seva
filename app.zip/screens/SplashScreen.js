import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const SplashScreen = () => {
  return (
    <View style={styles.splashScreen1}>
      <Text style={styles.nivrittiseva}>NivrittiSeva</Text>
      <Text style={[styles.yourBestMoney, styles.yourBestMoneyFlexBox]}>
        Your Best Money Transfer Partner.
      </Text>
      <Text
        style={[
          styles.securedByNivrittisevaContainer,
          styles.yourBestMoneyFlexBox,
        ]}
      >
        <Text style={styles.securedBy}>{`Secured by `}</Text>
        <Text style={styles.nivrittiseva1}>NivrittiSeva.</Text>
      </Text>
      <Image
        style={styles.image7Icon}
        contentFit="cover"
        source={require("../assets/image-7.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  yourBestMoneyFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  nivrittiseva: {
    top: 382,
    left: 57,
    fontSize: 54,
    lineHeight: 51,
    color: Color.colorDeepskyblue,
    textAlign: "center",
    fontFamily: FontFamily.dMSansRegular,
    position: "absolute",
  },
  yourBestMoney: {
    top: 445,
    left: 90,
    fontSize: FontSize.size_smi,
    fontWeight: "500",
    fontFamily: FontFamily.dMSansMedium,
    width: 217,
    color: Color.colorRoyalblue_300,
  },
  securedBy: {
    color: Color.colorGray_100,
  },
  nivrittiseva1: {
    color: Color.colorRoyalblue_300,
  },
  securedByNivrittisevaContainer: {
    top: 751,
    left: 107,
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.dMSansRegular,
  },
  image7Icon: {
    marginLeft: -126.5,
    top: 182,
    left: "50%",
    width: 253,
    height: 188,
    position: "absolute",
  },
  splashScreen1: {
    borderRadius: Border.br_29xl,
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    height: 852,
    overflow: "hidden",
  },
});

export default SplashScreen;
