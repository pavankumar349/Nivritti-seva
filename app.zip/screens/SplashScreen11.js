import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const SplashScreen11 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.splashScreen12}>
      <View style={styles.splashScreen12Child} />
      <Text style={styles.securityQuestions}>Security Questions</Text>
      <Pressable
        style={styles.rectangleParent}
        onPress={() => navigation.navigate("SplashScreen14")}
      >
        <View style={[styles.groupChild, styles.groupLayout1]} />
        <View style={[styles.groupItem, styles.groupLayout1]} />
      </Pressable>
      <Image
        style={styles.arrowToTopIcon}
        contentFit="cover"
        source={require("../assets/arrow-to-top.png")}
      />
      <Text style={styles.pleaseAddAtleast}>
        Please, add atleast 3 Questions to keep your account secured in case you
        forget your credentials.
      </Text>
      <View style={[styles.splashScreen12Item, styles.splashLayout]} />
      <View style={[styles.splashScreen12Inner, styles.splashLayout]} />
      <View style={[styles.rectangleView, styles.splashChildLayout1]} />
      <View style={[styles.splashScreen12Child1, styles.splashChildLayout1]} />
      <View style={[styles.splashScreen12Child2, styles.splashChildLayout1]} />
      <View style={[styles.splashScreen12Child3, styles.splashChildLayout1]} />
      <Text style={[styles.whatWasYour, styles.yourTypo]}>
        What was your First School’s name?
      </Text>
      <Text style={[styles.nameOfYour, styles.yourTypo]}>
        Name of your place of birth?
      </Text>
      <Text style={[styles.whatIsYour, styles.yourTypo]}>
        What is your elder brother’s name?
      </Text>
      <Text style={[styles.whatIsYour1, styles.yourTypo]}>
        What is your Grandfather’s name?
      </Text>
      <Text style={[styles.whatIsYour2, styles.yourTypo]}>
        What is your Mother’s name?
      </Text>
      <Text style={styles.whatIsYour3}>What is your cast?</Text>
      <Image
        style={[styles.groupIcon, styles.splashChildLayout]}
        contentFit="cover"
        source={require("../assets/group-54.png")}
      />
      <Image
        style={[styles.splashScreen12Child4, styles.splashChildLayout]}
        contentFit="cover"
        source={require("../assets/group-55.png")}
      />
      <Image
        style={[styles.splashScreen12Child5, styles.splashChildLayout]}
        contentFit="cover"
        source={require("../assets/group-56.png")}
      />
      <Pressable
        style={styles.rectangleGroup}
        onPress={() => navigation.navigate("SplashScreen12")}
      >
        <View style={[styles.groupInner, styles.groupLayout]} />
        <View style={[styles.groupChild1, styles.groupLayout]} />
        <Text style={styles.save}>Save</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  groupLayout1: {
    height: 36,
    backgroundColor: Color.colorDeepskyblue,
    borderRadius: Border.br_xl,
    width: 66,
    left: 0,
    position: "absolute",
  },
  splashLayout: {
    opacity: 0.05,
    height: 51,
    width: 359,
    borderRadius: Border.br_3xs,
    left: 18,
    position: "absolute",
  },
  splashChildLayout1: {
    height: 50,
    opacity: 0.05,
    width: 359,
    borderRadius: Border.br_3xs,
    left: 18,
    position: "absolute",
  },
  yourTypo: {
    height: 22,
    color: Color.colorRoyalblue_400,
    fontFamily: FontFamily.dMSansMedium,
    fontWeight: "500",
    lineHeight: 21,
    fontSize: FontSize.size_sm,
    left: 44,
    textAlign: "left",
    position: "absolute",
  },
  splashChildLayout: {
    height: 19,
    width: 19,
    left: 340,
    position: "absolute",
  },
  groupLayout: {
    height: 62,
    borderRadius: Border.br_31xl,
    width: 160,
    backgroundColor: Color.colorDeepskyblue,
    left: 0,
    position: "absolute",
  },
  splashScreen12Child: {
    width: 393,
    height: 851,
    left: 0,
    top: 0,
    position: "absolute",
    backgroundColor: Color.colorWhite,
  },
  securityQuestions: {
    top: 37,
    left: 122,
    fontSize: FontSize.size_xl,
    lineHeight: 42,
    color: Color.colorGray_200,
    width: 198,
    height: 44,
    textAlign: "left",
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
    position: "absolute",
  },
  groupChild: {
    top: 0,
  },
  groupItem: {
    top: 8,
  },
  rectangleParent: {
    top: 41,
    width: 66,
    left: 37,
    height: 44,
    position: "absolute",
  },
  arrowToTopIcon: {
    top: 46,
    left: 57,
    width: 25,
    height: 25,
    position: "absolute",
  },
  pleaseAddAtleast: {
    top: 125,
    fontSize: FontSize.size_mini,
    fontFamily: FontFamily.dMSansRegular,
    color: Color.colorGray_100,
    width: 321,
    height: 56,
    left: 37,
    textAlign: "left",
    position: "absolute",
  },
  splashScreen12Item: {
    top: 225,
    backgroundColor: Color.colorMediumslateblue,
  },
  splashScreen12Inner: {
    top: 380,
    backgroundColor: Color.colorMidnightblue,
  },
  rectangleView: {
    top: 458,
    backgroundColor: Color.colorMidnightblue,
  },
  splashScreen12Child1: {
    top: 536,
    backgroundColor: Color.colorMediumslateblue,
  },
  splashScreen12Child2: {
    top: 613,
    backgroundColor: Color.colorMidnightblue,
  },
  splashScreen12Child3: {
    top: 303,
    backgroundColor: Color.colorMediumslateblue,
  },
  whatWasYour: {
    top: 239,
    width: 257,
  },
  nameOfYour: {
    top: 394,
    width: 203,
  },
  whatIsYour: {
    top: 472,
    width: 250,
  },
  whatIsYour1: {
    top: 549,
    width: 244,
  },
  whatIsYour2: {
    top: 627,
    width: 208,
  },
  whatIsYour3: {
    top: 316,
    width: 131,
    height: 23,
    color: Color.colorRoyalblue_400,
    fontFamily: FontFamily.dMSansMedium,
    fontWeight: "500",
    lineHeight: 21,
    fontSize: FontSize.size_sm,
    left: 44,
    textAlign: "left",
    position: "absolute",
  },
  groupIcon: {
    top: 241,
  },
  splashScreen12Child4: {
    top: 551,
  },
  splashScreen12Child5: {
    top: 319,
  },
  groupInner: {
    top: 0,
  },
  groupChild1: {
    top: 14,
  },
  save: {
    top: 18,
    left: 51,
    fontSize: FontSize.size_3xl,
    color: Color.colorWhite,
    width: 53,
    height: 27,
    textAlign: "left",
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
    position: "absolute",
  },
  rectangleGroup: {
    top: 717,
    left: 118,
    height: 75,
    width: 160,
    position: "absolute",
  },
  splashScreen12: {
    borderRadius: Border.br_29xl,
    flex: 1,
    width: "100%",
    height: 852,
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
  },
});

export default SplashScreen11;
