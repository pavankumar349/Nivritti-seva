import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, Border, FontSize } from "../GlobalStyles";

const SplashScreen13 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.splashScreen14}>
      <View style={styles.splashScreen14Child} />
      <Image
        style={styles.arrowToTopIcon}
        contentFit="cover"
        source={require("../assets/arrow-to-top.png")}
      />
      <Image
        style={[styles.splashScreen14Item, styles.splashLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-44.png")}
      />
      <Image
        style={[styles.path395Icon, styles.splashLayout]}
        contentFit="cover"
        source={require("../assets/path-395.png")}
      />
      <Text
        style={[
          styles.accountRegistedSuccessfully,
          styles.splashScreen14InnerPosition,
        ]}
      >{`Account Registed
Successfully`}</Text>
      <Text style={[styles.congrats, styles.congratsTypo]}>Congrats!</Text>
      <Image
        style={[styles.splashScreen14Inner, styles.splashScreen14InnerPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-45.png")}
      />
      <Image
        style={[styles.ellipseIcon, styles.ellipseIconLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-46.png")}
      />
      <Image
        style={[styles.splashScreen14Child1, styles.ellipseIconLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-47.png")}
      />
      <Pressable
        style={styles.rectangleParent}
        onPress={() => navigation.navigate("SplashScreen15")}
      >
        <View style={[styles.groupChild, styles.groupLayout]} />
        <View style={[styles.groupItem, styles.groupLayout]} />
        <Text style={styles.great}>Great!</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  splashLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  splashScreen14InnerPosition: {
    opacity: 0.6,
    position: "absolute",
  },
  congratsTypo: {
    textAlign: "center",
    color: Color.colorDeepskyblue,
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
  },
  ellipseIconLayout: {
    height: "1.17%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  groupLayout: {
    height: 62,
    borderRadius: Border.br_31xl,
    width: 160,
    left: 0,
    position: "absolute",
  },
  splashScreen14Child: {
    width: 393,
    height: 851,
    left: 0,
    top: 0,
    position: "absolute",
    backgroundColor: Color.colorWhite,
  },
  arrowToTopIcon: {
    top: 46,
    left: 57,
    width: 25,
    height: 25,
    position: "absolute",
  },
  splashScreen14Item: {
    height: "25.59%",
    width: "55.47%",
    top: "18.43%",
    right: "22.14%",
    bottom: "55.99%",
    left: "22.39%",
    position: "absolute",
  },
  path395Icon: {
    height: "9.86%",
    width: "24.17%",
    top: "26.29%",
    right: "37.91%",
    bottom: "63.85%",
    left: "37.91%",
    position: "absolute",
  },
  accountRegistedSuccessfully: {
    top: 541,
    left: 17,
    fontSize: FontSize.size_base,
    letterSpacing: 0.1,
    lineHeight: 21,
    width: 359,
    height: 44,
    textAlign: "center",
    color: Color.colorDeepskyblue,
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
  },
  congrats: {
    top: 466,
    left: 39,
    fontSize: 55,
    letterSpacing: 0.2,
    lineHeight: 30,
    width: 315,
    height: 32,
    position: "absolute",
  },
  splashScreen14Inner: {
    height: "1.88%",
    width: "4.07%",
    top: "13.62%",
    right: "61.32%",
    bottom: "84.51%",
    left: "34.61%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  ellipseIcon: {
    width: "2.29%",
    top: "44.01%",
    right: "15.78%",
    bottom: "54.81%",
    left: "81.93%",
    opacity: 0.5,
  },
  splashScreen14Child1: {
    width: "2.54%",
    top: "38.03%",
    right: "81.42%",
    bottom: "60.8%",
    left: "16.03%",
    opacity: 0.25,
  },
  groupChild: {
    backgroundColor: Color.colorDeepskyblue,
    top: 0,
    borderRadius: Border.br_31xl,
  },
  groupItem: {
    top: 14,
    backgroundColor: "#5066c0",
  },
  great: {
    top: 18,
    left: 49,
    fontSize: FontSize.size_3xl,
    color: Color.colorWhite,
    textAlign: "left",
    width: 73,
    height: 28,
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
    position: "absolute",
  },
  rectangleParent: {
    top: 667,
    left: 116,
    height: 75,
    width: 160,
    position: "absolute",
  },
  splashScreen14: {
    borderRadius: Border.br_29xl,
    flex: 1,
    width: "100%",
    height: 852,
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
  },
});

export default SplashScreen13;
