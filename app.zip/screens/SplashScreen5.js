import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const SplashScreen5 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.splashScreen6}>
      <View style={styles.splashScreen6Child} />
      <View style={styles.rectangleParent}>
        <View style={[styles.groupChild, styles.groupLayout]} />
        <View style={[styles.groupItem, styles.groupLayout]} />
        <Text style={[styles.signUp, styles.signTypo]}>Sign Up</Text>
      </View>
      <Text style={[styles.signUp1, styles.signUp1Position]}>
        <Text style={styles.blankLine}> </Text>
        <Text style={styles.signUp2}>Sign Up</Text>
      </Text>
      <Text style={[styles.emailAddress, styles.passwordTypo]}>
        Email Address
      </Text>
      <Text style={[styles.alreadyHaveAnContainer, styles.confirmPasswordTypo]}>
        <Text style={styles.alreadyHaveAn}>Already have an account?</Text>
        <Text style={styles.text}>{` `}</Text>
        <Text style={styles.text}>
          <Text style={styles.login1}>Login</Text>
        </Text>
      </Text>
      <Pressable
        style={[styles.mainideasgmailcom, styles.signUp1Position]}
        onPress={() => navigation.navigate("SplashScreen6")}
      >
        <Text style={[styles.mainideasgmailcom1, styles.orTypo]}>
          Mainideas@gmail.com
        </Text>
      </Pressable>
      <Text style={[styles.password, styles.passwordTypo]}>Password</Text>
      <Text style={[styles.confirmPassword, styles.confirmPasswordTypo]}>
        Confirm Password
      </Text>
      <Text style={[styles.or, styles.orTypo]}>or</Text>
      <View style={styles.splashScreen6Item} />
      <View style={[styles.splashScreen6Inner, styles.lineViewBorder]} />
      <View style={[styles.lineView, styles.lineViewBorder]} />
      <View style={[styles.splashScreen6Child1, styles.splashChildLayout]} />
      <View style={[styles.splashScreen6Child2, styles.splashChildLayout]} />
      <View style={[styles.rectangleView, styles.rectangleViewLayout]} />
      <Image
        style={styles.googleIcon}
        contentFit="cover"
        source={require("../assets/google.png")}
      />
      <Image
        style={[styles.maskGroupIcon, styles.rectangleViewLayout]}
        contentFit="cover"
        source={require("../assets/mask-group.png")}
      />
      <Image
        style={[styles.maskGroupIcon1, styles.maskGroupLayout]}
        contentFit="cover"
        source={require("../assets/mask-group1.png")}
      />
      <Image
        style={[styles.maskGroupIcon2, styles.maskGroupLayout]}
        contentFit="cover"
        source={require("../assets/mask-group2.png")}
      />
      <Image
        style={[styles.groupIcon, styles.signUp1Position]}
        contentFit="cover"
        source={require("../assets/group-91.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  groupLayout: {
    height: 64,
    backgroundColor: Color.colorDeepskyblue,
    borderRadius: Border.br_xl,
    width: 217,
    left: 0,
    position: "absolute",
  },
  signTypo: {
    textAlign: "left",
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
  },
  signUp1Position: {
    left: 36,
    position: "absolute",
  },
  passwordTypo: {
    height: 17,
    color: Color.colorGray_100,
    fontFamily: FontFamily.dMSansMedium,
    fontWeight: "500",
    fontSize: FontSize.size_smi,
    left: 36,
    textAlign: "left",
    position: "absolute",
  },
  confirmPasswordTypo: {
    height: 18,
    fontFamily: FontFamily.dMSansMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  orTypo: {
    fontFamily: FontFamily.dMSansMedium,
    fontWeight: "500",
    textAlign: "left",
  },
  lineViewBorder: {
    borderColor: Color.colorDarkgray,
    height: 1,
    width: 334,
    borderTopWidth: 1,
    borderStyle: "solid",
    left: 36,
    position: "absolute",
  },
  splashChildLayout: {
    width: 86,
    top: 665,
    borderColor: Color.colorDarkgray,
    height: 1,
    borderTopWidth: 1,
    borderStyle: "solid",
    position: "absolute",
  },
  rectangleViewLayout: {
    height: 65,
    width: 65,
    top: 691,
    position: "absolute",
  },
  maskGroupLayout: {
    height: 14,
    width: 14,
    left: 353,
    position: "absolute",
  },
  splashScreen6Child: {
    width: 405,
    height: 877,
    left: 0,
    top: 0,
    position: "absolute",
    backgroundColor: Color.colorWhite,
  },
  groupChild: {
    top: 0,
    backgroundColor: Color.colorDeepskyblue,
    borderRadius: Border.br_xl,
  },
  groupItem: {
    top: 14,
  },
  signUp: {
    top: 17,
    left: 67,
    fontSize: FontSize.size_3xl,
    color: Color.colorWhite,
    width: 82,
    height: 28,
    position: "absolute",
  },
  rectangleParent: {
    top: 549,
    height: 78,
    width: 217,
    left: 94,
    position: "absolute",
  },
  blankLine: {
    color: Color.colorMediumslateblue,
  },
  signUp2: {
    color: Color.colorGray_200,
  },
  signUp1: {
    top: 80,
    fontSize: FontSize.size_21xl,
    lineHeight: 42,
    width: 151,
    height: 91,
    textAlign: "left",
    fontFamily: FontFamily.dMSansBold,
    fontWeight: "700",
  },
  emailAddress: {
    top: 224,
    width: 98,
  },
  alreadyHaveAn: {
    color: Color.colorGray_100,
  },
  text: {
    color: Color.colorDeepskyblue,
  },
  login1: {
    textDecoration: "underline",
  },
  alreadyHaveAnContainer: {
    top: 804,
    left: 98,
    fontSize: FontSize.size_sm,
    width: 209,
  },
  mainideasgmailcom1: {
    fontSize: FontSize.size_mini,
    color: Color.colorSilver,
    width: 161,
    height: 20,
  },
  mainideasgmailcom: {
    top: 259,
  },
  password: {
    top: 323,
    width: 60,
  },
  confirmPassword: {
    top: 422,
    width: 113,
    color: Color.colorGray_100,
    fontSize: FontSize.size_smi,
    height: 18,
    left: 36,
  },
  or: {
    top: 653,
    left: 195,
    fontSize: FontSize.size_base,
    color: Color.colorDarkgray,
    width: 17,
    height: 21,
    position: "absolute",
  },
  splashScreen6Item: {
    top: 296,
    borderColor: Color.colorSilver,
    height: 1,
    width: 334,
    borderTopWidth: 1,
    borderStyle: "solid",
    left: 36,
    position: "absolute",
  },
  splashScreen6Inner: {
    top: 395,
  },
  lineView: {
    top: 495,
  },
  splashScreen6Child1: {
    left: 94,
    width: 86,
    top: 665,
  },
  splashScreen6Child2: {
    left: 226,
  },
  rectangleView: {
    left: 114,
    borderRadius: Border.br_31xl,
    backgroundColor: Color.colorWhitesmoke,
  },
  googleIcon: {
    top: 706,
    left: 130,
    width: 34,
    height: 35,
    position: "absolute",
    overflow: "hidden",
  },
  maskGroupIcon: {
    left: 226,
  },
  maskGroupIcon1: {
    top: 365,
  },
  maskGroupIcon2: {
    top: 464,
  },
  groupIcon: {
    top: 58,
    width: 84,
    height: 51,
  },
  splashScreen6: {
    borderRadius: Border.br_29xl,
    flex: 1,
    width: "100%",
    height: 852,
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
  },
});

export default SplashScreen5;
